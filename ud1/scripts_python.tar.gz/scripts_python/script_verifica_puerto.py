#!/bin/env python3

def puerto_abierto(puerto):
	if puerto % 2 == 0 or puerto % 5 == 0:
		return True

for i in range(1,65535):
	if puerto_abierto(i):
		print(f"El puerto {i} está abierto")
